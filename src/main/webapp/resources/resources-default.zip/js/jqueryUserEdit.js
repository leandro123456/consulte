$(document).ready(function(){
	$("#password").hide();

	$("#1").click(function(){
	$("#password").show();
	});

	$("#2").click(function(){
	$("#password").hide();
	});
});