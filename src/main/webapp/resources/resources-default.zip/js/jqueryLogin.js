$(document).ready(function() {
	$("#sign").hide();

	$("#signup").hide();

	$("#userName").hide();

	$("#userPassword").hide();

	$("#codeQR").click(function(){
		$("#sign").show();
		$("#userName").show();
		$("#userPassword").show();

		$("#msg2Div").hide();
		$("#imgQRDiv").hide();
	});
});